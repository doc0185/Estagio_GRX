#include <stdio.h>

#define MAX 100

int main(){
	int n, j=0, i;
	int vet[MAX]={}, vetPar[MAX]={};
	
	printf ("Digite a quantidade de numeros que deseje analisar: ");
	scanf ("%d", &n);
		
	for (i=0; i<n; i++){
		scanf ("%d", &vet[i]);
		if (vet[i]%2==0){
			vetPar[j]=vet[i];
			j++;
		}
	}
	
	printf ("\n");
	
	for (i=0; i<j; i++){
		printf ("%d\n", vetPar[i]);
	}

}
